import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  Calendar, 
  User, 
  Package, 
  Store as StoreIcon, 
  Printer, 
  Download, 
  ArrowDownToLine, 
  ArrowUpFromLine, 
  Scale, 
  Box,
  FileText
} from 'lucide-react';
import { Product, StockMovement, Invoice, Shipment, Store } from '../types';
import { useAuth } from '../firebase/authContext';
import { exportStockAndMovementsPDF } from '../utils/pdfExport';

interface ReportsViewProps {
  products: Product[];
  movements: StockMovement[];
  invoices: Invoice[];
  shipments: Shipment[];
  stores: Store[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  products,
  movements,
  invoices,
  shipments,
  stores
}) => {
  const { currentUser } = useAuth();
  const [activeReportTab, setActiveReportTab] = useState<'monthly' | 'by_user' | 'by_product' | 'by_store'>('monthly');
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const handleExportPDF = () => {
    try {
      setIsExportingPdf(true);
      exportStockAndMovementsPDF(products, movements, currentUser?.name);
    } catch (err) {
      console.error('Erro ao gerar PDF:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Month selector for Monthly Report (YYYY-MM)
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });

  // User report filters
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [userStartDate, setUserStartDate] = useState('');
  const [userEndDate, setUserEndDate] = useState('');

  // Product report filters
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [prodStartDate, setProdStartDate] = useState('');
  const [prodEndDate, setProdEndDate] = useState('');

  // Store report filters
  const [selectedStoreId, setSelectedStoreId] = useState<string>('');
  const [storeStartDate, setStoreStartDate] = useState('');
  const [storeEndDate, setStoreEndDate] = useState('');

  // Available users list
  const availableUsers = useMemo(() => {
    const set = new Set<string>();
    movements.forEach(m => { if (m.userName) set.add(m.userName); });
    return Array.from(set);
  }, [movements]);

  // Set initial selected user
  React.useEffect(() => {
    if (!selectedUser && availableUsers.length > 0) {
      setSelectedUser(availableUsers[0]);
    }
  }, [availableUsers, selectedUser]);

  // 1. MONTHLY REPORT CALCULATIONS
  const monthlyData = useMemo(() => {
    const validMovements = movements.filter(m => {
      if (m.status === 'CANCELLED') return false;
      const mMonth = m.createdAtIso ? m.createdAtIso.substring(0, 7) : '';
      return mMonth === selectedMonth;
    });

    let entriesBoxes = 0;
    let entriesKg = 0;
    let exitsBoxes = 0;
    let exitsKg = 0;

    const productsMap = new Map<string, { code: string; name: string; entriesBoxes: number; entriesKg: number; exitsBoxes: number; exitsKg: number }>();

    for (const mov of validMovements) {
      if (!productsMap.has(mov.productId)) {
        productsMap.set(mov.productId, {
          code: mov.productCode,
          name: mov.productName,
          entriesBoxes: 0,
          entriesKg: 0,
          exitsBoxes: 0,
          exitsKg: 0
        });
      }
      const pEntry = productsMap.get(mov.productId)!;

      if (mov.type === 'ENTRADA') {
        entriesBoxes += mov.boxes;
        entriesKg += mov.weightKg;
        pEntry.entriesBoxes += mov.boxes;
        pEntry.entriesKg += mov.weightKg;
      } else {
        exitsBoxes += mov.boxes;
        exitsKg += mov.weightKg;
        pEntry.exitsBoxes += mov.boxes;
        pEntry.exitsKg += mov.weightKg;
      }
    }

    return {
      entriesBoxes,
      entriesKg,
      exitsBoxes,
      exitsKg,
      balanceBoxes: entriesBoxes - exitsBoxes,
      balanceKg: entriesKg - exitsKg,
      productsList: Array.from(productsMap.values()),
      totalOperations: validMovements.length
    };
  }, [movements, selectedMonth]);

  // 2. USER REPORT CALCULATIONS
  const userReportData = useMemo(() => {
    if (!selectedUser) return null;

    const userInvoices = invoices.filter(inv => {
      if (inv.userName !== selectedUser) return false;
      if (userStartDate && inv.date < userStartDate) return false;
      if (userEndDate && inv.date > userEndDate) return false;
      return true;
    });

    const userShipments = shipments.filter(ship => {
      if (ship.userName !== selectedUser) return false;
      if (userStartDate && ship.date < userStartDate) return false;
      if (userEndDate && ship.date > userEndDate) return false;
      return true;
    });

    const totalOps = userInvoices.length + userShipments.length;
    const totalEntriesBoxes = userInvoices.reduce((s, i) => s + (i.status === 'CONFIRMED' ? i.totalBoxes : 0), 0);
    const totalEntriesKg = userInvoices.reduce((s, i) => s + (i.status === 'CONFIRMED' ? i.totalWeightKg : 0), 0);
    const totalExitsBoxes = userShipments.reduce((s, i) => s + (i.status === 'CONFIRMED' ? i.totalBoxes : 0), 0);
    const totalExitsKg = userShipments.reduce((s, i) => s + (i.status === 'CONFIRMED' ? i.totalWeightKg : 0), 0);

    return {
      userInvoices,
      userShipments,
      totalOps,
      totalEntriesBoxes,
      totalEntriesKg,
      totalExitsBoxes,
      totalExitsKg
    };
  }, [invoices, shipments, selectedUser, userStartDate, userEndDate]);

  // 3. PRODUCT REPORT CALCULATIONS
  const productReportData = useMemo(() => {
    const prod = products.find(p => p.id === selectedProductId) || products[0];
    if (!prod) return null;

    const prodMovements = movements.filter(m => {
      if (m.productId !== prod.id) return false;
      if (m.status === 'CANCELLED') return false;
      const mDate = m.createdAtIso ? m.createdAtIso.split('T')[0] : '';
      if (prodStartDate && mDate < prodStartDate) return false;
      if (prodEndDate && mDate > prodEndDate) return false;
      return true;
    });

    let totalEntriesBoxes = 0;
    let totalEntriesKg = 0;
    let totalExitsBoxes = 0;
    let totalExitsKg = 0;

    for (const m of prodMovements) {
      if (m.type === 'ENTRADA') {
        totalEntriesBoxes += m.boxes;
        totalEntriesKg += m.weightKg;
      } else {
        totalExitsBoxes += m.boxes;
        totalExitsKg += m.weightKg;
      }
    }

    return {
      product: prod,
      totalEntriesBoxes,
      totalEntriesKg,
      totalExitsBoxes,
      totalExitsKg,
      balanceBoxes: totalEntriesBoxes - totalExitsBoxes,
      balanceKg: totalEntriesKg - totalExitsKg,
      movements: prodMovements
    };
  }, [products, movements, selectedProductId, prodStartDate, prodEndDate]);

  // 4. STORE REPORT CALCULATIONS
  const storeReportData = useMemo(() => {
    // Shipments items filtered by store and date
    const storeDeliveries = new Map<string, { storeName: string; totalBoxes: number; totalWeightKg: number; shipmentsCount: number; productsBreakdown: Map<string, { name: string; boxes: number; weightKg: number }> }>();

    for (const ship of shipments) {
      if (ship.status === 'CANCELLED') continue;
      if (storeStartDate && ship.date < storeStartDate) continue;
      if (storeEndDate && ship.date > storeEndDate) continue;

      for (const dest of ship.destinations) {
        if (selectedStoreId && dest.storeName !== selectedStoreId && dest.storeId !== selectedStoreId) continue;

        if (!storeDeliveries.has(dest.storeName)) {
          storeDeliveries.set(dest.storeName, {
            storeName: dest.storeName,
            totalBoxes: 0,
            totalWeightKg: 0,
            shipmentsCount: 0,
            productsBreakdown: new Map()
          });
        }

        const storeData = storeDeliveries.get(dest.storeName)!;
        storeData.shipmentsCount += 1;
        storeData.totalBoxes += dest.subtotalBoxes;
        storeData.totalWeightKg += dest.subtotalWeightKg;

        for (const item of dest.items) {
          if (!storeData.productsBreakdown.has(item.productId)) {
            storeData.productsBreakdown.set(item.productId, {
              name: item.productName,
              boxes: 0,
              weightKg: 0
            });
          }
          const p = storeData.productsBreakdown.get(item.productId)!;
          p.boxes += item.quantityBoxes;
          p.weightKg += item.weightKg;
        }
      }
    }

    return Array.from(storeDeliveries.values());
  }, [shipments, selectedStoreId, storeStartDate, storeEndDate]);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-blue-600" />
            Central de Relatórios Gerenciais
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Análise consolidada por Mês, Usuário responsável, Produto e Lojas de destino.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportPDF}
            disabled={isExportingPdf}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold text-xs rounded-lg transition shadow-xs cursor-pointer"
            title="Baixar resumo de estoque e movimentações em documento PDF formatado"
          >
            <Download className="w-4 h-4" />
            {isExportingPdf ? 'Gerando PDF...' : 'Exportar PDF'}
          </button>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-lg transition cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            Imprimir
          </button>
        </div>
      </div>

      {/* Report Selection Tabs */}
      <div className="flex border-b border-slate-200 overflow-x-auto gap-2 bg-white px-4 pt-2 rounded-t-xl border-t border-x">
        <button
          onClick={() => setActiveReportTab('monthly')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition ${
            activeReportTab === 'monthly'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          Relatório Mensal de Estoque
        </button>

        <button
          onClick={() => setActiveReportTab('by_user')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition ${
            activeReportTab === 'by_user'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <User className="w-4 h-4" />
          Relatório por Usuário
        </button>

        <button
          onClick={() => setActiveReportTab('by_product')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition ${
            activeReportTab === 'by_product'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Package className="w-4 h-4" />
          Relatório por Produto
        </button>

        <button
          onClick={() => setActiveReportTab('by_store')}
          className={`flex items-center gap-2 py-3 px-4 border-b-2 font-bold text-xs sm:text-sm whitespace-nowrap transition ${
            activeReportTab === 'by_store'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <StoreIcon className="w-4 h-4" />
          Relatório por Loja
        </button>
      </div>

      {/* 1. MONTHLY REPORT CONTENT */}
      {activeReportTab === 'monthly' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-b-xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-700 uppercase">Selecione o Mês:</span>
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <span className="text-xs text-slate-500">
              Total de movimentações: <strong>{monthlyData.totalOperations}</strong>
            </span>
          </div>

          {/* Monthly KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs border-l-4 border-l-emerald-600">
              <span className="text-xs font-bold text-slate-500 uppercase block">Total de Entradas no Mês</span>
              <div className="mt-2 text-2xl font-black text-slate-900 font-mono">
                {monthlyData.entriesBoxes} cx
              </div>
              <div className="text-sm font-bold text-emerald-700 font-mono mt-0.5">
                {monthlyData.entriesKg.toLocaleString('pt-BR', { minimumFractionDigits: 1 })} kg
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs border-l-4 border-l-blue-600">
              <span className="text-xs font-bold text-slate-500 uppercase block">Total de Saídas no Mês</span>
              <div className="mt-2 text-2xl font-black text-slate-900 font-mono">
                {monthlyData.exitsBoxes} cx
              </div>
              <div className="text-sm font-bold text-blue-700 font-mono mt-0.5">
                {monthlyData.exitsKg.toLocaleString('pt-BR', { minimumFractionDigits: 1 })} kg
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs border-l-4 border-l-slate-800">
              <span className="text-xs font-bold text-slate-500 uppercase block">Saldo Operacional do Mês</span>
              <div className="mt-2 text-2xl font-black text-slate-900 font-mono">
                {monthlyData.balanceBoxes >= 0 ? `+${monthlyData.balanceBoxes}` : monthlyData.balanceBoxes} cx
              </div>
              <div className="text-sm font-bold text-slate-700 font-mono mt-0.5">
                {monthlyData.balanceKg >= 0 ? `+${monthlyData.balanceKg.toFixed(1)}` : monthlyData.balanceKg.toFixed(1)} kg
              </div>
            </div>
          </div>

          {/* Products moved in the month */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 font-bold text-xs uppercase text-slate-700">
              Produtos Movimentados no Mês Selecionado
            </div>
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50/50 text-xs text-slate-500 uppercase border-b">
                <tr>
                  <th className="p-3">Código</th>
                  <th className="p-3">Produto</th>
                  <th className="p-3 text-right">Entradas (cx)</th>
                  <th className="p-3 text-right">Entradas (kg)</th>
                  <th className="p-3 text-right">Saídas (cx)</th>
                  <th className="p-3 text-right">Saídas (kg)</th>
                  <th className="p-3 text-right">Saldo do Mês (cx)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {monthlyData.productsList.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400 text-xs">
                      Nenhum produto movimentado neste mês.
                    </td>
                  </tr>
                ) : (
                  monthlyData.productsList.map((p, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="p-3 font-mono font-bold text-blue-700">{p.code}</td>
                      <td className="p-3 font-semibold text-slate-900">{p.name}</td>
                      <td className="p-3 text-right text-emerald-700 font-semibold">{p.entriesBoxes} cx</td>
                      <td className="p-3 text-right text-emerald-700">{p.entriesKg.toFixed(1)} kg</td>
                      <td className="p-3 text-right text-blue-700 font-semibold">{p.exitsBoxes} cx</td>
                      <td className="p-3 text-right text-blue-700">{p.exitsKg.toFixed(1)} kg</td>
                      <td className="p-3 text-right font-black text-slate-900">{p.entriesBoxes - p.exitsBoxes} cx</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. USER REPORT CONTENT */}
      {activeReportTab === 'by_user' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-b-xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Selecionar Usuário</label>
              <select
                value={selectedUser}
                onChange={(e) => setSelectedUser(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm font-semibold bg-white"
              >
                {availableUsers.map(u => (
                  <option key={u} value={u}>{u}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data Inicial</label>
              <input
                type="date"
                value={userStartDate}
                onChange={(e) => setUserStartDate(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data Final</label>
              <input
                type="date"
                value={userEndDate}
                onChange={(e) => setUserEndDate(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
              />
            </div>
          </div>

          {userReportData && (
            <div className="space-y-6">
              {/* Operations KPI */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-xs font-bold text-slate-500 uppercase">Total de Operações Lançadas</span>
                  <div className="mt-2 text-2xl font-black text-slate-900 font-mono">
                    {userReportData.totalOps} operações
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {userReportData.userInvoices.length} Notas Fiscais + {userReportData.userShipments.length} Romaneios
                  </p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-xs font-bold text-slate-500 uppercase">Entradas Recebidas pelo Usuário</span>
                  <div className="mt-2 text-xl font-bold text-emerald-800 font-mono">
                    {userReportData.totalEntriesBoxes} cx ({userReportData.totalEntriesKg.toFixed(1)} kg)
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-xs font-bold text-slate-500 uppercase">Saídas Expedidas pelo Usuário</span>
                  <div className="mt-2 text-xl font-bold text-blue-800 font-mono">
                    {userReportData.totalExitsBoxes} cx ({userReportData.totalExitsKg.toFixed(1)} kg)
                  </div>
                </div>
              </div>

              {/* Lists of Invoices and Romaneios by this user */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Notas Lançadas */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                  <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 font-bold text-xs uppercase text-slate-800 flex justify-between">
                    <span>Notas Fiscais Registradas ({userReportData.userInvoices.length})</span>
                  </div>
                  <div className="p-4 divide-y divide-slate-100 max-h-72 overflow-y-auto text-xs">
                    {userReportData.userInvoices.length === 0 ? (
                      <p className="text-slate-400 py-4 text-center">Nenhuma nota lançada por este usuário no período.</p>
                    ) : (
                      userReportData.userInvoices.map(inv => (
                        <div key={inv.id} className="py-2.5 flex justify-between items-center">
                          <div>
                            <span className="font-mono font-bold text-blue-700 text-sm">NF {inv.invoiceNumber}</span>
                            <span className="text-slate-500 block">{inv.supplierName} • {inv.date}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-bold text-slate-800">{inv.totalBoxes} cx</span>
                            <span className="text-slate-500 block">{inv.totalWeightKg.toFixed(1)} kg</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Romaneios Lançados */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                  <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 font-bold text-xs uppercase text-slate-800 flex justify-between">
                    <span>Romaneios Registrados ({userReportData.userShipments.length})</span>
                  </div>
                  <div className="p-4 divide-y divide-slate-100 max-h-72 overflow-y-auto text-xs">
                    {userReportData.userShipments.length === 0 ? (
                      <p className="text-slate-400 py-4 text-center">Nenhum romaneio lançado por este usuário no período.</p>
                    ) : (
                      userReportData.userShipments.map(ship => (
                        <div key={ship.id} className="py-2.5 flex justify-between items-center">
                          <div>
                            <span className="font-mono font-bold text-blue-700 text-sm">Romaneio Nº {ship.romaneioNumber}</span>
                            <span className="text-slate-500 block">{ship.destinations?.length} loja(s) • {ship.date}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-bold text-slate-800">{ship.totalBoxes} cx</span>
                            <span className="text-slate-500 block">{ship.totalWeightKg.toFixed(1)} kg</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. PRODUCT REPORT CONTENT */}
      {activeReportTab === 'by_product' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-b-xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Selecionar Produto</label>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm font-semibold bg-white"
              >
                {products.map(p => (
                  <option key={p.id} value={p.id}>{p.code} - {p.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data Inicial</label>
              <input
                type="date"
                value={prodStartDate}
                onChange={(e) => setProdStartDate(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data Final</label>
              <input
                type="date"
                value={prodEndDate}
                onChange={(e) => setProdEndDate(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
              />
            </div>
          </div>

          {productReportData && (
            <div className="space-y-6">
              {/* Product Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-xs font-bold text-slate-500 uppercase">Produto Selecionado</span>
                  <div className="mt-1 font-mono font-bold text-blue-700 text-lg">{productReportData.product.code}</div>
                  <div className="font-bold text-slate-900">{productReportData.product.name}</div>
                  <span className="text-[11px] text-slate-400">{productReportData.product.unit} (~{productReportData.product.defaultWeightKg} kg)</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-xs font-bold text-slate-500 uppercase">Total de Entradas</span>
                  <div className="mt-1 text-2xl font-black text-emerald-800 font-mono">{productReportData.totalEntriesBoxes} cx</div>
                  <div className="text-xs font-bold text-emerald-700 font-mono">{productReportData.totalEntriesKg.toFixed(1)} kg</div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-xs font-bold text-slate-500 uppercase">Total de Saídas</span>
                  <div className="mt-1 text-2xl font-black text-blue-800 font-mono">{productReportData.totalExitsBoxes} cx</div>
                  <div className="text-xs font-bold text-blue-700 font-mono">{productReportData.totalExitsKg.toFixed(1)} kg</div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <span className="text-xs font-bold text-slate-500 uppercase">Saldo no Período</span>
                  <div className="mt-1 text-2xl font-black text-slate-900 font-mono">{productReportData.balanceBoxes} cx</div>
                  <div className="text-xs font-bold text-slate-700 font-mono">{productReportData.balanceKg.toFixed(1)} kg</div>
                </div>
              </div>

              {/* Product movements table */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 font-bold text-xs uppercase text-slate-700">
                  Movimentações do Produto ({productReportData.movements.length})
                </div>
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50/50 text-xs text-slate-500 uppercase border-b">
                    <tr>
                      <th className="p-3">Tipo</th>
                      <th className="p-3">Documento</th>
                      <th className="p-3">Data</th>
                      <th className="p-3 text-right">Caixas</th>
                      <th className="p-3 text-right">Peso (kg)</th>
                      <th className="p-3">Fornecedor / Loja</th>
                      <th className="p-3">Usuário</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-xs">
                    {productReportData.movements.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="p-8 text-center text-slate-400">
                          Nenhuma movimentação registrada para este produto no período.
                        </td>
                      </tr>
                    ) : (
                      productReportData.movements.map(m => (
                        <tr key={m.id} className="hover:bg-slate-50">
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${m.type === 'ENTRADA' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'}`}>
                              {m.type}
                            </span>
                          </td>
                          <td className="p-3 font-mono font-bold text-slate-900">{m.documentNumber}</td>
                          <td className="p-3 text-slate-600">{m.createdAtIso ? m.createdAtIso.split('T')[0] : '—'}</td>
                          <td className="p-3 text-right font-bold text-slate-900">{m.boxes} cx</td>
                          <td className="p-3 text-right font-bold text-slate-900">{m.weightKg.toFixed(1)} kg</td>
                          <td className="p-3 text-slate-600">{m.supplierName || m.storeName || '—'}</td>
                          <td className="p-3 text-slate-600">{m.userName}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. STORE REPORT CONTENT */}
      {activeReportTab === 'by_store' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-b-xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Filtrar Loja</label>
              <select
                value={selectedStoreId}
                onChange={(e) => setSelectedStoreId(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm font-semibold bg-white"
              >
                <option value="">Todas as Lojas</option>
                {stores.map(st => (
                  <option key={st.id} value={st.name}>{st.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data Inicial</label>
              <input
                type="date"
                value={storeStartDate}
                onChange={(e) => setStoreStartDate(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data Final</label>
              <input
                type="date"
                value={storeEndDate}
                onChange={(e) => setStoreEndDate(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {storeReportData.length === 0 ? (
              <div className="col-span-2 bg-white p-12 text-center rounded-xl border border-slate-200 text-slate-400">
                Nenhum romaneio expedido para lojas no período selecionado.
              </div>
            ) : (
              storeReportData.map((st, idx) => (
                <div key={idx} className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                  <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                    <div>
                      <h3 className="font-bold text-base text-slate-900 uppercase flex items-center gap-2">
                        <StoreIcon className="w-4 h-4 text-emerald-600" />
                        {st.storeName}
                      </h3>
                      <span className="text-xs text-slate-500">{st.shipmentsCount} romaneio(s) entregue(s)</span>
                    </div>
                    <div className="text-right">
                      <div className="text-base font-black text-blue-700 font-mono">{st.totalBoxes} cx</div>
                      <div className="text-xs font-bold text-emerald-700 font-mono">{st.totalWeightKg.toFixed(1)} kg</div>
                    </div>
                  </div>

                  <div className="p-4">
                    <span className="text-xs font-bold text-slate-600 uppercase mb-2 block">
                      Detalhamento de Produtos Enviados:
                    </span>
                    <table className="w-full text-left text-xs">
                      <thead className="text-slate-400 border-b pb-1">
                        <tr>
                          <th className="py-1">Produto</th>
                          <th className="py-1 text-right">Caixas</th>
                          <th className="py-1 text-right">Peso (kg)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {Array.from(st.productsBreakdown.values()).map((p, pIdx) => (
                          <tr key={pIdx} className="hover:bg-slate-50">
                            <td className="py-1.5 font-semibold text-slate-800">{p.name}</td>
                            <td className="py-1.5 text-right font-medium text-slate-900">{p.boxes} cx</td>
                            <td className="py-1.5 text-right font-bold text-emerald-700">{p.weightKg.toFixed(1)} kg</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
