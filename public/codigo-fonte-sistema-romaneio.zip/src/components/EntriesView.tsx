import React, { useState, useId } from 'react';
import { 
  ArrowDownToLine, 
  Plus, 
  Trash2, 
  Save, 
  FileText, 
  Scale, 
  Box, 
  Calendar, 
  Building2, 
  User, 
  AlertCircle, 
  CheckCircle2, 
  Info, 
  Search,
  Eye,
  XCircle,
  Clock
} from 'lucide-react';
import { Product, Invoice, InvoiceItem, Supplier } from '../types';
import { registerInvoiceEntry, cancelInvoice } from '../services/inventoryService';
import { useAuth } from '../firebase/authContext';

interface EntriesViewProps {
  products: Product[];
  invoices: Invoice[];
  suppliers: Supplier[];
  onOpenNewProduct: () => void;
}

export const EntriesView: React.FC<EntriesViewProps> = ({ 
  products, 
  invoices, 
  suppliers,
  onOpenNewProduct 
}) => {
  const { currentUser } = useAuth();

  // Form Header State
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [supplierName, setSupplierName] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  // Items State
  const [items, setItems] = useState<InvoiceItem[]>([]);

  // Item Form Input State (for adding item)
  const [selectedProductId, setSelectedProductId] = useState('');
  const [entryMode, setEntryMode] = useState<'by_unit' | 'by_weight'>('by_unit');
  const [quantityInput, setQuantityInput] = useState<number | string>(10);
  const [weightInput, setWeightInput] = useState<number | string>(200);

  // UI States
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);
  const [cancellingInvoice, setCancellingInvoice] = useState<Invoice | null>(null);
  const [cancelReason, setCancelReason] = useState('');

  // Handle product selection and set initial suggested values
  const handleProductChange = (prodId: string) => {
    setSelectedProductId(prodId);
    const prod = products.find(p => p.id === prodId);
    if (prod) {
      const defaultWeight = prod.defaultWeightKg || 20;
      const qty = Number(quantityInput) || 10;
      setQuantityInput(qty);
      setWeightInput(Math.round(qty * defaultWeight * 100) / 100);
    }
  };

  // When quantity in boxes changes: allows free manual typing without overwriting weight
  const handleQuantityChange = (val: string) => {
    setQuantityInput(val);
  };

  // When weight in kg changes: allows free manual typing without overwriting quantity
  const handleWeightChange = (val: string) => {
    setWeightInput(val);
  };

  // Helper to suggest standard weight based on packaging
  const handleSuggestStandardWeight = () => {
    const qty = Number(quantityInput) || 0;
    const prod = products.find(p => p.id === selectedProductId);
    if (prod && prod.defaultWeightKg > 0 && qty > 0) {
      setWeightInput(Math.round(qty * prod.defaultWeightKg * 100) / 100);
    }
  };

  // Helper to suggest boxes from total weight
  const handleSuggestBoxesFromWeight = () => {
    const wt = Number(weightInput) || 0;
    const prod = products.find(p => p.id === selectedProductId);
    if (prod && prod.defaultWeightKg > 0 && wt > 0) {
      setQuantityInput(Math.round((wt / prod.defaultWeightKg) * 100) / 100);
    }
  };

  // Inline manipulation of quantity or weight directly in the invoice items table
  const handleUpdateItemProperty = (itemId: string, field: 'quantityBoxes' | 'weightKg', val: number) => {
    setItems(prev => prev.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          [field]: Math.max(0, val)
        };
      }
      return item;
    }));
  };

  // Add Item to Invoice Items list
  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!selectedProductId) {
      setErrorMessage('Selecione um produto para adicionar à nota.');
      return;
    }

    const prod = products.find(p => p.id === selectedProductId);
    if (!prod) {
      setErrorMessage('Produto não encontrado.');
      return;
    }

    const qty = Number(quantityInput);
    const weight = Number(weightInput);

    if (qty <= 0 && weight <= 0) {
      setErrorMessage('Informe uma quantidade ou peso maior que zero.');
      return;
    }

    const newItem: InvoiceItem = {
      id: Math.random().toString(36).substring(2, 9),
      productId: prod.id,
      productCode: prod.code,
      productName: prod.name,
      unit: prod.unit,
      quantityBoxes: qty,
      weightKg: weight,
      mode: entryMode
    };

    setItems([...items, newItem]);
    setSelectedProductId('');
    setQuantityInput(10);
    setWeightInput(200);
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  // Summaries
  const totalBoxes = items.reduce((sum, item) => sum + item.quantityBoxes, 0);
  const totalWeightKg = items.reduce((sum, item) => sum + item.weightKg, 0);

  // Save Invoice
  const handleSaveInvoice = async () => {
    setErrorMessage(null);

    if (!invoiceNumber.trim()) {
      setErrorMessage('O número da nota fiscal é obrigatório.');
      return;
    }

    if (!supplierName.trim()) {
      setErrorMessage('O nome do fornecedor é obrigatório.');
      return;
    }

    if (items.length === 0) {
      setErrorMessage('Adicione pelo menos um produto à nota fiscal antes de salvar.');
      return;
    }

    if (!currentUser) {
      setErrorMessage('Usuário não autenticado.');
      return;
    }

    setIsSubmitting(true);
    try {
      await registerInvoiceEntry({
        invoiceNumber,
        supplierName,
        date,
        notes,
        items,
        user: currentUser
      });

      setSuccessMessage(`Nota Fiscal ${invoiceNumber} registrada com sucesso no Firebase! Estoque atualizado.`);
      // Reset form
      setInvoiceNumber('');
      setSupplierName('');
      setNotes('');
      setItems([]);
      setDate(new Date().toISOString().split('T')[0]);
      setTimeout(() => setSuccessMessage(null), 5000);
    } catch (err: any) {
      setErrorMessage(err.message || 'Erro ao registrar nota fiscal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmCancel = async () => {
    if (!cancellingInvoice || !currentUser) return;
    if (!cancelReason.trim()) {
      alert('Informe o motivo do cancelamento.');
      return;
    }

    try {
      await cancelInvoice(cancellingInvoice.id, currentUser, cancelReason);
      setCancellingInvoice(null);
      setCancelReason('');
      setSuccessMessage(`Nota Fiscal ${cancellingInvoice.invoiceNumber} cancelada e estoque estornado.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Erro ao cancelar nota.');
    }
  };

  const activeProducts = products.filter(p => p.active);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <ArrowDownToLine className="w-6 h-6 text-emerald-600" />
            Entrada de Mercadorias (Notas Fiscais)
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Lance notas fiscais de fornecedores com múltiplos produtos e controle consistente de caixas e peso (kg).
          </p>
        </div>

        {/* Current logged-in user badge (immutable per requirement 9) */}
        <div className="flex items-center gap-2.5 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-lg">
          <User className="w-4 h-4 text-slate-500" />
          <div className="text-left">
            <div className="text-[11px] text-slate-400 font-medium">Responsável pelo Lançamento:</div>
            <div className="text-xs font-bold text-slate-800">{currentUser?.name}</div>
          </div>
        </div>
      </div>

      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-sm flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-sm flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Form: Invoice Header & Product Input */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: Invoice Data & Add Product */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Section 1: Nota Fiscal Info */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" />
              1. Dados da Nota Fiscal
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Número da Nota Fiscal <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  placeholder="Ex: 1234"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-bold text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Fornecedor <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  list="suppliersList"
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  placeholder="Ex: Fornecedor ABC"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
                <datalist id="suppliersList">
                  {suppliers.map(s => (
                    <option key={s.id} value={s.name} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Data da Entrada <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Observações (Opcional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ex: Carga descarregada na câmara frigorífica 2"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          {/* Section 2: Product Inserter */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Box className="w-4 h-4 text-emerald-600" />
                2. Adicionar Produtos à Nota Fiscal
              </h2>
              {activeProducts.length === 0 && (
                <button
                  type="button"
                  onClick={onOpenNewProduct}
                  className="text-xs text-blue-600 hover:underline font-semibold"
                >
                  + Cadastrar produtos primeiro
                </button>
              )}
            </div>

            <form onSubmit={handleAddItem} className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
              {/* Product selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Selecione o Produto (Código / Nome)
                </label>
                <select
                  value={selectedProductId}
                  onChange={(e) => handleProductChange(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white"
                  required
                >
                  <option value="">-- Selecione o produto --</option>
                  {activeProducts.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.code} — {p.name} ({p.unit} ~{p.defaultWeightKg} kg)
                      {p.supplierName ? ` • Forn: ${p.supplierName}` : ''}
                      {p.salePrice && p.salePrice > 0 ? ` • Venda: R$ ${p.salePrice.toFixed(2)}` : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Mode switch & Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                {/* Mode Selector */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                    Forma de Lançamento
                  </label>
                  <div className="grid grid-cols-2 rounded-lg border border-slate-300 p-0.5 bg-white text-xs">
                    <button
                      type="button"
                      onClick={() => setEntryMode('by_unit')}
                      className={`py-1.5 rounded-md font-medium transition ${
                        entryMode === 'by_unit' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      Por Caixas
                    </button>
                    <button
                      type="button"
                      onClick={() => setEntryMode('by_weight')}
                      className={`py-1.5 rounded-md font-medium transition ${
                        entryMode === 'by_weight' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      Por Quilos
                    </button>
                  </div>
                </div>

                {/* Boxes / Units Input */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-700 uppercase">
                      Qtd (Caixas / Unid)
                    </label>
                    <button
                      type="button"
                      onClick={handleSuggestBoxesFromWeight}
                      className="text-[10px] text-blue-600 hover:underline font-medium"
                      title="Calcular caixas com base no peso e peso padrão do produto"
                    >
                      ⚡ Calcular caixas
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="any"
                      min="0.01"
                      value={quantityInput}
                      onChange={(e) => handleQuantityChange(e.target.value)}
                      placeholder="Ex: 10"
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white outline-none font-bold text-slate-900"
                      required
                    />
                  </div>
                </div>

                {/* Weight Input */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-700 uppercase">
                      Peso Total (kg)
                    </label>
                    <button
                      type="button"
                      onClick={handleSuggestStandardWeight}
                      className="text-[10px] text-emerald-600 hover:underline font-medium"
                      title="Calcular peso sugerido com base nas caixas x peso padrão"
                    >
                      ⚡ Sugerir peso padrão
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={weightInput}
                      onChange={(e) => handleWeightChange(e.target.value)}
                      placeholder="Ex: 200.00"
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-white outline-none font-bold text-slate-900"
                      required
                    />
                    <span className="absolute right-3 top-2 text-xs font-bold text-slate-400">kg</span>
                  </div>
                </div>
              </div>

              {/* Manipulation info note */}
              <div className="text-[11px] text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 flex items-center justify-between">
                <span>💡 <strong>Manipulação Livre:</strong> Você pode digitar livremente tanto as caixas quanto o peso real aferido na balança.</span>
              </div>

              {/* Add Button */}
              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  disabled={!selectedProductId}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-semibold text-sm rounded-lg transition shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  Adicionar Produto à Nota
                </button>
              </div>
            </form>
          </div>

          {/* Section 3: Items Table in this Invoice */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Produtos Adicionados à Nota ({items.length})
              </span>
              <span className="text-xs text-slate-500">
                Você pode manipular as caixas e pesos diretamente nos campos da tabela abaixo
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50/50 text-[11px] uppercase font-semibold text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-2.5">Cód</th>
                    <th className="px-4 py-2.5">Produto</th>
                    <th className="px-4 py-2.5 text-center">Unidade</th>
                    <th className="px-4 py-2.5 text-right">Qtd (Caixas / Manipular)</th>
                    <th className="px-4 py-2.5 text-right">Peso Real (kg / Manipular)</th>
                    <th className="px-4 py-2.5 text-center">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-4 py-8 text-center text-slate-400 text-xs">
                        Nenhum item adicionado ainda. Preencha os campos acima e clique em "Adicionar Produto à Nota".
                      </td>
                    </tr>
                  ) : (
                    items.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/60">
                        <td className="px-4 py-2.5 font-mono font-bold text-blue-700">
                          {item.productCode}
                        </td>
                        <td className="px-4 py-2.5 font-semibold text-slate-900">
                          {item.productName}
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <span className="text-xs bg-slate-100 px-2 py-0.5 rounded text-slate-700 font-medium">
                            {item.unit}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-right">
                          <input
                            type="number"
                            step="any"
                            min="0"
                            value={item.quantityBoxes}
                            onChange={(e) => handleUpdateItemProperty(item.id, 'quantityBoxes', Number(e.target.value))}
                            className="w-24 px-2 py-1 text-right text-sm font-bold text-blue-800 border border-slate-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white"
                            title="Clique para manipular a quantidade de caixas"
                          />
                        </td>
                        <td className="px-4 py-2.5 text-right">
                          <div className="inline-flex items-center gap-1 justify-end">
                            <input
                              type="number"
                              step="0.01"
                              min="0"
                              value={item.weightKg}
                              onChange={(e) => handleUpdateItemProperty(item.id, 'weightKg', Number(e.target.value))}
                              className="w-28 px-2 py-1 text-right text-sm font-bold text-emerald-800 border border-slate-300 rounded focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 bg-white"
                              title="Clique para manipular o peso aferido em kg"
                            />
                            <span className="text-xs font-semibold text-slate-500">kg</span>
                          </div>
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="text-slate-400 hover:text-rose-600 p-1 rounded"
                            title="Remover produto da nota"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right: Summary Before Saving & Save Button */}
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-5 sticky top-20">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
              <Info className="w-4 h-4 text-blue-600" />
              Resumo da Nota Fiscal
            </h2>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Nota Fiscal:</span>
                <span className="font-bold text-slate-900">{invoiceNumber || '—'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Fornecedor:</span>
                <span className="font-semibold text-slate-800 truncate max-w-[150px]">{supplierName || '—'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Data de Entrada:</span>
                <span className="text-slate-800">{date}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Itens Distintos:</span>
                <span className="font-semibold text-slate-900">{items.length} produto(s)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Total de Caixas:</span>
                <span className="font-bold text-blue-700 text-base">{totalBoxes} cx</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Peso Total Bruto:</span>
                <span className="font-bold text-emerald-700 text-base">
                  {totalWeightKg.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} kg
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Usuário Responsável:</span>
                <span className="text-xs font-semibold text-slate-700">{currentUser?.name}</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={handleSaveInvoice}
                disabled={isSubmitting || items.length === 0 || !invoiceNumber || !supplierName}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-sm rounded-xl transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <Save className="w-5 h-5" />
                {isSubmitting ? 'Gravando no Firebase...' : 'CONFIRMAR E SALVAR NOTA'}
              </button>
              <p className="text-[11px] text-slate-400 text-center mt-2">
                Ao salvar, a movimentação é gravada permanentemente no Firebase e o estoque é incrementado.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Invoices History Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden mt-8">
        <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-slate-600" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              Notas Fiscais de Entrada Registradas
            </h3>
          </div>
          <span className="text-xs text-slate-500">
            Total: <strong>{invoices.length}</strong> notas
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-xs uppercase font-semibold text-slate-700 border-b border-slate-200">
              <tr>
                <th className="px-5 py-3">Nota Fiscal</th>
                <th className="px-5 py-3">Data</th>
                <th className="px-5 py-3">Fornecedor</th>
                <th className="px-5 py-3 text-right">Itens</th>
                <th className="px-5 py-3 text-right">Total Caixas</th>
                <th className="px-5 py-3 text-right">Peso (kg)</th>
                <th className="px-5 py-3">Usuário</th>
                <th className="px-5 py-3 text-center">Status</th>
                <th className="px-5 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-6 py-8 text-center text-slate-400 text-xs">
                    Nenhuma nota fiscal registrada no sistema ainda.
                  </td>
                </tr>
              ) : (
                invoices.map((inv) => (
                  <tr key={inv.id} className={`hover:bg-slate-50/80 ${inv.status === 'CANCELLED' ? 'bg-slate-100/50 opacity-60' : ''}`}>
                    <td className="px-5 py-3 font-mono font-bold text-blue-700">
                      NF {inv.invoiceNumber}
                    </td>
                    <td className="px-5 py-3 text-slate-700">
                      {inv.date}
                    </td>
                    <td className="px-5 py-3 font-medium text-slate-900">
                      {inv.supplierName}
                    </td>
                    <td className="px-5 py-3 text-right text-slate-700">
                      {inv.items?.length || 0}
                    </td>
                    <td className="px-5 py-3 text-right font-medium text-slate-900">
                      {inv.totalBoxes} cx
                    </td>
                    <td className="px-5 py-3 text-right font-bold text-emerald-700">
                      {inv.totalWeightKg.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} kg
                    </td>
                    <td className="px-5 py-3 text-xs text-slate-600">
                      {inv.userName}
                    </td>
                    <td className="px-5 py-3 text-center">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${
                        inv.status === 'CONFIRMED' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {inv.status === 'CONFIRMED' ? 'Confirmada' : 'Cancelada'}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right space-x-1 whitespace-nowrap">
                      <button
                        onClick={() => setViewingInvoice(inv)}
                        className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded"
                        title="Ver itens da nota"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      {inv.status === 'CONFIRMED' && (
                        <button
                          onClick={() => setCancellingInvoice(inv)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"
                          title="Cancelar / Estornar nota"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Details Modal */}
      {viewingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-lg text-slate-900">
                  Detalhes da Nota Fiscal {viewingInvoice.invoiceNumber}
                </h3>
                <p className="text-xs text-slate-500">
                  Fornecedor: {viewingInvoice.supplierName} • Data: {viewingInvoice.date} • Lançado por: {viewingInvoice.userName}
                </p>
              </div>
              <button
                onClick={() => setViewingInvoice(null)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-6">
              {viewingInvoice.status === 'CANCELLED' && (
                <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs">
                  <strong>Nota Cancelada por:</strong> {viewingInvoice.cancelledByUserName || 'Usuário'} <br />
                  <strong>Motivo:</strong> {viewingInvoice.cancelReason || 'Sem motivo informado'}
                </div>
              )}

              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-700 border-b">
                  <tr>
                    <th className="p-2">Cód</th>
                    <th className="p-2">Produto</th>
                    <th className="p-2 text-right">Caixas</th>
                    <th className="p-2 text-right">Peso (kg)</th>
                    <th className="p-2 text-center">Modo</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {viewingInvoice.items?.map((it) => (
                    <tr key={it.id}>
                      <td className="p-2 font-mono font-bold text-blue-700">{it.productCode}</td>
                      <td className="p-2 font-medium text-slate-900">{it.productName}</td>
                      <td className="p-2 text-right">{it.quantityBoxes} cx</td>
                      <td className="p-2 text-right font-bold text-emerald-700">{it.weightKg.toFixed(2)} kg</td>
                      <td className="p-2 text-center text-xs text-slate-500">{it.mode === 'by_unit' ? 'Por Caixas' : 'Por Quilos'}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="border-t font-bold bg-slate-50">
                  <tr>
                    <td colSpan={2} className="p-2 text-right text-slate-700">Totais:</td>
                    <td className="p-2 text-right text-blue-700">{viewingInvoice.totalBoxes} cx</td>
                    <td className="p-2 text-right text-emerald-700">{viewingInvoice.totalWeightKg.toFixed(2)} kg</td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>

              {viewingInvoice.notes && (
                <p className="mt-4 text-xs text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <strong>Observações:</strong> {viewingInvoice.notes}
                </p>
              )}
            </div>

            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setViewingInvoice(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-sm font-semibold rounded-lg"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Invoice Modal */}
      {cancellingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md border border-slate-200 overflow-hidden">
            <div className="p-5 bg-rose-50 border-b border-rose-200 flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-rose-600" />
              <div>
                <h3 className="font-bold text-rose-950 text-base">
                  Cancelar Nota Fiscal {cancellingInvoice.invoiceNumber}?
                </h3>
                <p className="text-xs text-rose-700">
                  Esta ação irá estornar as quantidades e pesos do estoque e registrar a auditoria.
                </p>
              </div>
            </div>

            <div className="p-5 space-y-3">
              <label className="block text-xs font-semibold text-slate-700 uppercase">
                Motivo do Cancelamento <span className="text-rose-500">*</span>
              </label>
              <textarea
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Ex: Erro de digitação na quantidade de contrafilé informado pela portaria..."
                className="w-full p-2.5 text-sm border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-rose-500"
                rows={3}
                required
              />
            </div>

            <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex justify-end gap-2">
              <button
                onClick={() => {
                  setCancellingInvoice(null);
                  setCancelReason('');
                }}
                className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-200 rounded-lg"
              >
                Voltar
              </button>
              <button
                onClick={handleConfirmCancel}
                disabled={!cancelReason.trim()}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-sm font-bold rounded-lg shadow-sm"
              >
                Confirmar Cancelamento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
