export type UnitType = 'CAIXA' | 'PACOTE' | 'PECA' | 'UNIDADE' | 'FARDO' | 'KG';

export interface Product {
  id: string;
  code: string; // Strictly 2 to 4 digits: e.g. "101", "102"
  name: string; // e.g. "CONTRAFILÉ"
  unit: UnitType; // e.g. "CAIXA"
  defaultWeightKg: number; // e.g. 20 kg
  supplierId?: string; // ID do Fornecedor associado
  supplierName?: string; // Nome do Fornecedor (ex: Frigorífico Estrela)
  salePrice?: number; // Preço/Valor de venda (R$)
  salePriceType?: 'POR_KG' | 'POR_UNIDADE'; // R$ por kg ou R$ por unidade/caixa
  active: boolean;
  createdAt: any;
  updatedAt: any;
  isSampleData?: boolean;
}

export interface InvoiceItem {
  id: string;
  productId: string;
  productCode: string;
  productName: string;
  unit: UnitType;
  quantityBoxes: number;
  weightKg: number;
  mode: 'by_unit' | 'by_weight';
}

export interface Invoice {
  id: string;
  invoiceNumber: string; // e.g. "1234"
  supplierName: string;
  date: string; // YYYY-MM-DD
  notes?: string;
  userId: string;
  userName: string;
  items: InvoiceItem[];
  totalBoxes: number;
  totalWeightKg: number;
  createdAt: any;
  status: 'CONFIRMED' | 'CANCELLED';
  cancelledAt?: any;
  cancelledByUserId?: string;
  cancelledByUserName?: string;
  cancelReason?: string;
}

export interface ShipmentItem {
  id: string;
  productId: string;
  productCode: string;
  productName: string;
  unit: UnitType;
  quantityBoxes: number;
  weightKg: number;
  mode: 'by_unit' | 'by_weight';
  defaultWeightKg?: number;
  conversionText?: string;
  unitPrice?: number; // Preço unitário (R$)
  priceType?: 'POR_KG' | 'POR_UNIDADE'; // Base de cálculo do preço
  totalPrice?: number; // Valor a ser pago neste produto (R$)
  supplierId?: string;
  supplierName?: string; // Fornecedor da mercadoria
}

export interface ShipmentDestination {
  id: string;
  storeId: string;
  storeName: string;
  items: ShipmentItem[];
  subtotalBoxes: number;
  subtotalWeightKg: number;
  subtotalPrice?: number; // Valor subtotal a pagar por esta loja (R$)
}

export interface Shipment {
  id: string;
  romaneioNumber: string; // e.g. "000123"
  date: string; // YYYY-MM-DD
  notes?: string;
  userId: string;
  userName: string;
  destinations: ShipmentDestination[];
  totalBoxes: number;
  totalWeightKg: number;
  totalPrice?: number; // Valor total a ser pago no romaneio (R$)
  supplierName?: string; // Fornecedor da mercadoria (quando aplicável ao romaneio todo)
  createdAt: any;
  status: 'CONFIRMED' | 'CANCELLED';
  cancelledAt?: any;
  cancelledByUserId?: string;
  cancelledByUserName?: string;
  cancelReason?: string;
  updatedAt?: any;
  lastModifiedByUserId?: string;
  lastModifiedByUserName?: string;
  weightAdjustmentNotes?: string;
}

export interface StockMovement {
  id: string;
  type: 'ENTRADA' | 'SAIDA';
  documentType: 'NOTA_FISCAL' | 'ROMANEIO' | 'AJUSTE' | 'INVENTARIO';
  documentNumber: string; // e.g. "NF 1234" or "ROMANEIO 000123" or "AJUSTE 2026-09-23"
  documentId: string;
  storeId?: string;
  storeName?: string;
  supplierName?: string;
  productId: string;
  productCode: string;
  productName: string;
  unit: UnitType;
  boxes: number;
  weightKg: number;
  mode: 'by_unit' | 'by_weight';
  userId: string;
  userName: string;
  timestamp: any;
  createdAtIso: string;
  notes?: string;
  status: 'CONFIRMED' | 'CANCELLED';
  cancelledByUserId?: string;
  cancelledByUserName?: string;
  cancelReason?: string;
}

export interface ProductStockSummary {
  productId: string;
  productCode: string;
  productName: string;
  unit: UnitType;
  defaultWeightKg: number;
  supplierId?: string;
  supplierName?: string;
  salePrice?: number;
  salePriceType?: 'POR_KG' | 'POR_UNIDADE';
  totalEntriesBoxes: number;
  totalEntriesWeightKg: number;
  totalExitsBoxes: number;
  totalExitsWeightKg: number;
  currentBoxes: number;
  currentWeightKg: number;
  active: boolean;
}

export interface Store {
  id: string;
  code?: string;
  name: string; // e.g. "Loja 01 - Centro"
  address?: string;
  active: boolean;
  createdAt?: any;
}

export interface Supplier {
  id: string;
  name: string;
  cnpj?: string;
  phone?: string;
  active: boolean;
  createdAt?: any;
}

export interface SystemSettings {
  allowNegativeStock: boolean;
  companyName: string;
  companyCnpj: string;
  companyPhone: string;
  companyAddress: string;
  nextRomaneioNumber: number;
}

export interface UserAccount {
  id: string;
  name: string;
  username?: string;
  role: 'ADMIN GERAL' | 'Administrador' | 'Operador' | 'Gerente' | 'Conferente';
  email: string;
  avatarColor?: string;
  pin?: string;
  password?: string;
  description?: string;
  department?: string;
}

export type AuditAction = 
  | 'EXCLUSAO_NOTA'
  | 'CANCELAMENTO_NOTA'
  | 'EXCLUSAO_ROMANEIO'
  | 'CANCELAMENTO_ROMANEIO'
  | 'AJUSTE_PESO_ROMANEIO'
  | 'EXCLUSAO_PRODUTO'
  | 'CRIACAO_PRODUTO'
  | 'ALTERACAO_PRODUTO'
  | 'EXCLUSAO_LOJA'
  | 'CRIACAO_LOJA'
  | 'ALTERACAO_LOJA'
  | 'AJUSTE_ESTOQUE'
  | 'ALTERACAO_CONFIGURACAO';

export interface AuditLogEntry {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  action: AuditAction;
  actionLabel: string;
  targetType: 'NOTA' | 'PRODUTO' | 'ROMANEIO' | 'LOJA' | 'FORNECEDOR' | 'ESTOQUE' | 'CONFIGURACAO';
  targetId: string;
  targetIdentifier: string;
  reason?: string;
  details?: any;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM:SS
  createdAt?: any;
}
